import React, { useState, useEffect, useMemo } from 'react';
import { Task, ProjectSettings, Phase, Priority, TaskStatus } from './types/project';
import { INITIAL_TASKS, INITIAL_PROJECT_START_DATE } from './data/initialData';
import { recalculateSchedule } from './utils/scheduleCalculator';
import { exportTasksToCSV } from './utils/exportUtils';
import { TopBar } from './components/TopBar';
import { KPISummary } from './components/KPISummary';
import { FilterBar } from './components/FilterBar';
import { GanttView } from './components/GanttView';
import { TableView } from './components/TableView';
import { KanbanView } from './components/KanbanView';
import { TopologyView } from './components/TopologyView';
import { CriticalPathView } from './components/CriticalPathView';
import { TaskModal } from './components/TaskModal';
import { TaskDetailDrawer } from './components/TaskDetailDrawer';

export default function App() {
  // Theme state
  const [isDark, setIsDark] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    }
    return false;
  });

  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDark]);

  const toggleDark = () => setIsDark((prev) => !prev);

  // Active navigation view
  const [activeTab, setActiveTab] = useState<'gantt' | 'table' | 'kanban' | 'topology' | 'risks'>('gantt');

  // Start Date input (YYYY-MM-DD)
  const [startDateInput, setStartDateInput] = useState<string>(INITIAL_PROJECT_START_DATE);

  // Tasks raw state
  const [tasksRaw, setTasksRaw] = useState<Task[]>(() => {
    // Try restoring from localStorage or use initial
    const saved = localStorage.getItem('uts_fortinet_tasks_v1');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return INITIAL_TASKS;
      }
    }
    return INITIAL_TASKS;
  });

  // Calculate schedule dynamically
  const { recalculatedTasks, settings } = useMemo(() => {
    return recalculateSchedule(tasksRaw, startDateInput, 5);
  }, [tasksRaw, startDateInput]);

  // Save to local storage on changes
  useEffect(() => {
    localStorage.setItem('uts_fortinet_tasks_v1', JSON.stringify(tasksRaw));
  }, [tasksRaw]);

  // Filters state
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPhase, setSelectedPhase] = useState('all');
  const [selectedPriority, setSelectedPriority] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [onlyCritical, setOnlyCritical] = useState(false);

  // Modals state
  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [selectedDrawerTaskId, setSelectedDrawerTaskId] = useState<number | null>(null);

  // Available phases
  const phases: Phase[] = useMemo(() => {
    const set = new Set<Phase>();
    recalculatedTasks.forEach((t) => set.add(t.fase));
    return Array.from(set);
  }, [recalculatedTasks]);

  // Filtered tasks
  const filteredTasks = useMemo(() => {
    return recalculatedTasks.filter((task) => {
      // Search
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesActividad = task.actividad.toLowerCase().includes(q);
        const matchesResp = task.responsable.toLowerCase().includes(q);
        const matchesId = String(task.id) === q || `#${task.id}` === q;
        if (!matchesActividad && !matchesResp && !matchesId) return false;
      }

      // Phase
      if (selectedPhase !== 'all' && task.fase !== selectedPhase) {
        return false;
      }

      // Priority
      if (selectedPriority !== 'all' && task.prioridad !== selectedPriority) {
        return false;
      }

      // Status
      if (selectedStatus !== 'all' && task.estado !== selectedStatus) {
        return false;
      }

      // Only Critical
      if (onlyCritical && !task.esCritica) {
        return false;
      }

      return true;
    });
  }, [recalculatedTasks, searchQuery, selectedPhase, selectedPriority, selectedStatus, onlyCritical]);

  // Task mutation handlers
  const handleUpdateTask = (id: number, updates: Partial<Task>) => {
    setTasksRaw((prev) =>
      prev.map((t) => {
        if (t.id === id) {
          return { ...t, ...updates };
        }
        return t;
      })
    );
  };

  const handleUpdateStatus = (id: number, status: TaskStatus) => {
    handleUpdateTask(id, { estado: status });
  };

  const handleUpdateDuration = (id: number, newDuration: number) => {
    handleUpdateTask(id, { duracion: Math.max(1, newDuration) });
  };

  const handleDeleteTask = (id: number) => {
    if (window.confirm(`¿Estás seguro de eliminar la actividad #${id}?`)) {
      setTasksRaw((prev) => prev.filter((t) => t.id !== id));
      if (selectedDrawerTaskId === id) setSelectedDrawerTaskId(null);
    }
  };

  const handleSaveModalTask = (taskData: Partial<Task>) => {
    if (taskData.id) {
      // Edit
      handleUpdateTask(taskData.id, taskData);
    } else {
      // New
      const nextId = tasksRaw.length > 0 ? Math.max(...tasksRaw.map((t) => t.id)) + 1 : 1;
      const newTask: Task = {
        id: nextId,
        fase: taskData.fase || 'Análisis',
        prioridad: taskData.prioridad || 'Media',
        actividad: taskData.actividad || 'Nueva Actividad',
        responsable: taskData.responsable || 'Equipo del proyecto',
        dependeDe: taskData.dependeDe || '—',
        duracion: taskData.duracion || 3,
        diaInicio: 1,
        diaFin: taskData.duracion || 3,
        fechaInicio: '',
        fechaFin: '',
        estado: taskData.estado || 'Pendiente',
        semanas: [],
        notas: taskData.notas || '',
      };
      setTasksRaw((prev) => [...prev, newTask]);
    }
    setEditingTask(null);
  };

  const handleResetToExcel = () => {
    if (window.confirm('¿Deseas restablecer todos los valores originales del Excel de UTS? Se perderán las modificaciones locales.')) {
      setTasksRaw(INITIAL_TASKS);
      setStartDateInput(INITIAL_PROJECT_START_DATE);
      localStorage.removeItem('uts_fortinet_tasks_v1');
    }
  };

  const handleExportCSV = () => {
    exportTasksToCSV(recalculatedTasks, settings);
  };

  // Find currently open drawer task
  const drawerTask = useMemo(() => {
    if (selectedDrawerTaskId === null) return null;
    return recalculatedTasks.find((t) => t.id === selectedDrawerTaskId) || null;
  }, [selectedDrawerTaskId, recalculatedTasks]);

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans transition-colors">
      {/* 1-Row 3-Zone Top Bar */}
      <TopBar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isDark={isDark}
        toggleDark={toggleDark}
        onOpenNewTask={() => {
          setEditingTask(null);
          setIsTaskModalOpen(true);
        }}
        onExportCSV={handleExportCSV}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* Executive KPI Summary Header */}
        <KPISummary
          tasks={recalculatedTasks}
          settings={settings}
          onSelectTask={(id) => setSelectedDrawerTaskId(id)}
        />

        {/* Global Controls & Filters (visible in timeline and matrix views) */}
        {(activeTab === 'gantt' || activeTab === 'table' || activeTab === 'kanban') && (
          <FilterBar
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
            selectedPhase={selectedPhase}
            setSelectedPhase={setSelectedPhase}
            selectedPriority={selectedPriority}
            setSelectedPriority={setSelectedPriority}
            selectedStatus={selectedStatus}
            setSelectedStatus={setSelectedStatus}
            onlyCritical={onlyCritical}
            setOnlyCritical={setOnlyCritical}
            startDateInput={startDateInput}
            setStartDateInput={setStartDateInput}
            onReset={handleResetToExcel}
            phases={phases}
          />
        )}

        {/* Tab Views */}
        {activeTab === 'gantt' && (
          <GanttView
            tasks={filteredTasks}
            settings={settings}
            onUpdateStatus={handleUpdateStatus}
            onSelectTask={(id) => setSelectedDrawerTaskId(id)}
          />
        )}

        {activeTab === 'table' && (
          <TableView
            tasks={filteredTasks}
            settings={settings}
            onUpdateTask={handleUpdateTask}
            onDeleteTask={handleDeleteTask}
            onOpenNewTask={() => {
              setEditingTask(null);
              setIsTaskModalOpen(true);
            }}
            onSelectTask={(id) => setSelectedDrawerTaskId(id)}
          />
        )}

        {activeTab === 'kanban' && (
          <KanbanView
            tasks={filteredTasks}
            onUpdateStatus={handleUpdateStatus}
            onSelectTask={(id) => setSelectedDrawerTaskId(id)}
          />
        )}

        {activeTab === 'topology' && <TopologyView />}

        {activeTab === 'risks' && (
          <CriticalPathView
            tasks={recalculatedTasks}
            settings={settings}
            onSelectTask={(id) => setSelectedDrawerTaskId(id)}
            onUpdateDuration={handleUpdateDuration}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="mt-auto border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 py-4 text-xs text-slate-500 dark:text-slate-400">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div>
            <span>Unidades Tecnológicas de Santander (UTS)</span>
            <span aria-hidden="true"> · </span>
            <span>Modernización de Red Fortinet Security Fabric</span>
          </div>
          <div className="flex items-center gap-3">
            <span>Objetivo: 5.000 usuarios concurrentes</span>
            <span aria-hidden="true">·</span>
            <span>SLA 99.5%</span>
          </div>
        </div>
      </footer>

      {/* Task Edit / Create Modal */}
      <TaskModal
        isOpen={isTaskModalOpen}
        onClose={() => {
          setIsTaskModalOpen(false);
          setEditingTask(null);
        }}
        task={editingTask}
        onSave={handleSaveModalTask}
        existingTasks={recalculatedTasks}
      />

      {/* Task Detail Drawer */}
      <TaskDetailDrawer
        task={drawerTask}
        onClose={() => setSelectedDrawerTaskId(null)}
        onEdit={(task) => {
          setEditingTask(task);
          setIsTaskModalOpen(true);
        }}
        onUpdateStatus={handleUpdateStatus}
        allTasks={recalculatedTasks}
      />
    </div>
  );
}
