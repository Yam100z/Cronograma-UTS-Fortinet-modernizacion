import React, { useState } from 'react';
import { Task, ProjectSettings, Priority, TaskStatus, Phase } from '../types/project';
import { Plus, Trash2, Edit2, CheckCircle2, Clock, AlertTriangle, ArrowUpDown } from 'lucide-react';

interface TableViewProps {
  tasks: Task[];
  settings: ProjectSettings;
  onUpdateTask: (id: number, updates: Partial<Task>) => void;
  onDeleteTask: (id: number) => void;
  onOpenNewTask: () => void;
  onSelectTask: (id: number) => void;
}

export const TableView: React.FC<TableViewProps> = ({
  tasks,
  settings,
  onUpdateTask,
  onDeleteTask,
  onOpenNewTask,
  onSelectTask,
}) => {
  const [editingId, setEditingId] = useState<number | null>(null);

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg overflow-hidden">
      {/* Table Header Controls */}
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-semibold text-slate-900 dark:text-slate-100">
              Matriz Editable de Actividades (Modelo Excel UTS)
            </h2>
          </div>
          <p className="text-xs text-amber-700 dark:text-amber-400 mt-0.5 flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-xs bg-amber-300 dark:bg-amber-500 inline-block border border-amber-400 dark:border-amber-600" />
            <span>Celdas amarillas = datos editables. Día inicio / Día fin / Fechas / Semanas se recalculan automáticamente.</span>
          </p>
        </div>

        <button
          onClick={onOpenNewTask}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 dark:bg-slate-100 dark:text-slate-900 dark:hover:bg-white rounded transition-colors whitespace-nowrap self-start sm:self-auto"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Nueva Actividad</span>
        </button>
      </div>

      {/* Spreadsheet Grid */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs border-collapse">
          <thead>
            <tr className="bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-700 font-semibold text-slate-700 dark:text-slate-200">
              <th className="p-2.5 text-center w-10">#</th>
              <th className="p-2.5 min-w-[100px]">Fase</th>
              <th className="p-2.5 min-w-[90px]">Prioridad</th>
              <th className="p-2.5 min-w-[260px]">Actividad / Tarea</th>
              <th className="p-2.5 min-w-[180px]">Responsable</th>
              <th className="p-2.5 min-w-[90px] text-center">Depende de</th>
              <th className="p-2.5 min-w-[90px] text-right bg-amber-100/50 dark:bg-amber-950/40 border-x border-amber-200 dark:border-amber-900/40">
                Duración (días)
              </th>
              <th className="p-2.5 text-right font-mono text-slate-500">Día inicio</th>
              <th className="p-2.5 text-right font-mono text-slate-500">Día fin</th>
              <th className="p-2.5 font-mono text-slate-500">Fecha inicio</th>
              <th className="p-2.5 font-mono text-slate-500">Fecha fin</th>
              <th className="p-2.5 min-w-[110px]">Estado</th>
              <th className="p-2.5 text-center font-mono text-slate-500">Holgura</th>
              <th className="p-2.5 text-center">Acciones</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
            {tasks.map((task) => {
              const isHighPriority = task.prioridad === 'Alta';

              return (
                <tr
                  key={task.id}
                  className={`hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors ${
                    task.esCritica ? 'bg-amber-50/15 dark:bg-amber-950/10' : ''
                  }`}
                >
                  {/* Task ID with critical badge */}
                  <td className="p-2.5 text-center font-mono font-bold text-slate-600 dark:text-slate-400">
                    <span
                      className={`inline-block w-5 h-5 rounded leading-5 text-center ${
                        task.esCritica
                          ? 'bg-amber-100 text-amber-800 dark:bg-amber-900/60 dark:text-amber-200 ring-1 ring-amber-400'
                          : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300'
                      }`}
                    >
                      {task.id}
                    </span>
                  </td>

                  {/* Fase (Editable) */}
                  <td className="p-2.5 bg-amber-50/30 dark:bg-amber-950/15">
                    <select
                      value={task.fase}
                      onChange={(e) => onUpdateTask(task.id, { fase: e.target.value as Phase })}
                      className="bg-transparent border-b border-transparent hover:border-amber-400 focus:border-amber-600 text-slate-900 dark:text-slate-100 py-0.5 text-xs font-medium focus:outline-none"
                    >
                      <option value="Análisis">Análisis</option>
                      <option value="Instalación">Instalación</option>
                      <option value="Migración">Migración</option>
                      <option value="Configuración">Configuración</option>
                      <option value="Pruebas">Pruebas</option>
                      <option value="Capacitación">Capacitación</option>
                      <option value="Go-Live">Go-Live</option>
                    </select>
                  </td>

                  {/* Prioridad (Editable) */}
                  <td className="p-2.5 bg-amber-50/30 dark:bg-amber-950/15">
                    <select
                      value={task.prioridad}
                      onChange={(e) => onUpdateTask(task.id, { prioridad: e.target.value as Priority })}
                      className={`py-0.5 text-xs font-semibold rounded bg-transparent border-b border-transparent focus:outline-none ${
                        task.prioridad === 'Alta'
                          ? 'text-red-600 dark:text-red-400'
                          : task.prioridad === 'Media'
                          ? 'text-emerald-600 dark:text-emerald-400'
                          : 'text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      <option value="Alta">Alta (Rojo)</option>
                      <option value="Media">Media (Verde)</option>
                      <option value="Baja">Baja</option>
                    </select>
                  </td>

                  {/* Actividad / Tarea (Editable) */}
                  <td className="p-2.5 bg-amber-50/30 dark:bg-amber-950/15 font-medium text-slate-900 dark:text-slate-100">
                    <input
                      type="text"
                      value={task.actividad}
                      onChange={(e) => onUpdateTask(task.id, { actividad: e.target.value })}
                      className="w-full bg-transparent border-b border-transparent hover:border-amber-400 focus:border-amber-600 py-0.5 text-xs focus:outline-none"
                    />
                  </td>

                  {/* Responsable (Editable) */}
                  <td className="p-2.5 bg-amber-50/30 dark:bg-amber-950/15 text-slate-700 dark:text-slate-300">
                    <input
                      type="text"
                      value={task.responsable}
                      onChange={(e) => onUpdateTask(task.id, { responsable: e.target.value })}
                      className="w-full bg-transparent border-b border-transparent hover:border-amber-400 focus:border-amber-600 py-0.5 text-xs focus:outline-none"
                    />
                  </td>

                  {/* Depende de (Editable) */}
                  <td className="p-2.5 bg-amber-50/30 dark:bg-amber-950/15 text-center">
                    <input
                      type="text"
                      value={task.dependeDe}
                      onChange={(e) => onUpdateTask(task.id, { dependeDe: e.target.value })}
                      placeholder="—"
                      className="w-16 text-center font-mono bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded py-0.5 text-xs focus:outline-none focus:ring-1 focus:ring-amber-500"
                    />
                  </td>

                  {/* Duración (Días) - Highlighted Editable Field with Stepper */}
                  <td className="p-2.5 text-right bg-amber-100/60 dark:bg-amber-950/40 border-x border-amber-200 dark:border-amber-900/50">
                    <div className="flex items-center justify-end gap-1">
                      <button
                        onClick={() => onUpdateTask(task.id, { duracion: Math.max(1, task.duracion - 1) })}
                        className="w-4 h-4 rounded bg-amber-200 hover:bg-amber-300 dark:bg-amber-900 dark:hover:bg-amber-800 text-slate-800 dark:text-slate-200 flex items-center justify-center font-bold text-xs"
                      >
                        -
                      </button>
                      <input
                        type="number"
                        min="1"
                        max="60"
                        value={task.duracion}
                        onChange={(e) =>
                          onUpdateTask(task.id, { duracion: Math.max(1, parseInt(e.target.value, 10) || 1) })
                        }
                        className="w-10 text-right font-mono font-bold bg-white dark:bg-slate-900 border border-amber-300 dark:border-amber-700 rounded py-0.5 px-1 text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-1 focus:ring-amber-500"
                      />
                      <button
                        onClick={() => onUpdateTask(task.id, { duracion: task.duracion + 1 })}
                        className="w-4 h-4 rounded bg-amber-200 hover:bg-amber-300 dark:bg-amber-900 dark:hover:bg-amber-800 text-slate-800 dark:text-slate-200 flex items-center justify-center font-bold text-xs"
                      >
                        +
                      </button>
                    </div>
                  </td>

                  {/* Auto-recalculated Columns */}
                  <td className="p-2.5 text-right font-mono text-slate-600 dark:text-slate-400 tabular-nums">
                    {task.diaInicio}
                  </td>
                  <td className="p-2.5 text-right font-mono text-slate-600 dark:text-slate-400 tabular-nums font-semibold">
                    {task.diaFin}
                  </td>
                  <td className="p-2.5 font-mono text-slate-600 dark:text-slate-400 tabular-nums">
                    {task.fechaInicio}
                  </td>
                  <td className="p-2.5 font-mono text-slate-900 dark:text-slate-200 tabular-nums font-semibold">
                    {task.fechaFin}
                  </td>

                  {/* Estado (Editable) */}
                  <td className="p-2.5 bg-amber-50/30 dark:bg-amber-950/15">
                    <select
                      value={task.estado}
                      onChange={(e) => onUpdateTask(task.id, { estado: e.target.value as TaskStatus })}
                      className={`py-0.5 px-1.5 text-xs font-medium rounded border border-transparent focus:outline-none ${
                        task.estado === 'Completada'
                          ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-200'
                          : task.estado === 'En curso'
                          ? 'bg-blue-100 dark:bg-blue-950/60 text-blue-800 dark:text-blue-200'
                          : task.estado === 'Bloqueada'
                          ? 'bg-rose-100 dark:bg-rose-950/60 text-rose-800 dark:text-rose-200'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      <option value="Pendiente">Pendiente</option>
                      <option value="En curso">En curso</option>
                      <option value="Completada">Completada</option>
                      <option value="Bloqueada">Bloqueada</option>
                    </select>
                  </td>

                  {/* Holgura */}
                  <td className="p-2.5 text-center font-mono tabular-nums">
                    {task.holgura === 0 ? (
                      <span className="text-amber-600 dark:text-amber-400 font-bold" title="Ruta crítica (0 días)">
                        0d (Crítica)
                      </span>
                    ) : (
                      <span className="text-slate-500 dark:text-slate-400">
                        {task.holgura}d
                      </span>
                    )}
                  </td>

                  {/* Acciones */}
                  <td className="p-2.5 text-center">
                    <div className="flex items-center justify-center gap-1.5">
                      <button
                        onClick={() => onSelectTask(task.id)}
                        title="Ver detalles"
                        className="p-1 text-slate-500 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded transition-colors"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      {tasks.length > 1 && (
                        <button
                          onClick={() => onDeleteTask(task.id)}
                          title="Eliminar actividad"
                          className="p-1 text-slate-400 hover:text-red-600 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/50 rounded transition-colors"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Footer Info */}
      <div className="p-3 bg-slate-50 dark:bg-slate-800/40 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
        <span>Modifica las celdas amarillas para ver el recálculo dinámico en tiempo real.</span>
        <span className="font-mono">{tasks.length} registros cargados</span>
      </div>
    </div>
  );
};
