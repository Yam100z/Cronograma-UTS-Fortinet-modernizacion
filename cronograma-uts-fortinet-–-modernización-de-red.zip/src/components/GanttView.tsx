import React, { useState } from 'react';
import { Task, ProjectSettings } from '../types/project';
import { getWeekDateRanges, parseDateInput } from '../utils/scheduleCalculator';
import { Check, Clock, AlertCircle, ArrowRight } from 'lucide-react';

interface GanttViewProps {
  tasks: Task[];
  settings: ProjectSettings;
  onUpdateStatus: (id: number, status: Task['estado']) => void;
  onSelectTask: (id: number) => void;
}

export const GanttView: React.FC<GanttViewProps> = ({
  tasks,
  settings,
  onUpdateStatus,
  onSelectTask,
}) => {
  const [viewMode, setViewMode] = useState<'weekly' | 'daily'>('weekly');
  const startDate = parseDateInput(settings.fechaInicio);
  const weekRanges = getWeekDateRanges(startDate, settings.totalSemanas, settings.diasPorSemana);

  // For daily view: days from 1 to max totalDiasHabiles
  const totalDays = Math.max(39, settings.totalDiasHabiles);
  const daysArray = Array.from({ length: totalDays }, (_, i) => i + 1);

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg overflow-hidden">
      {/* Gantt Header & Controls */}
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-base font-semibold text-slate-900 dark:text-slate-100">
            Cronograma Interactivo de Actividades
          </h2>
          <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            <span>Días hábiles lun-vie</span>
            <span aria-hidden="true">·</span>
            <span>{settings.totalSemanas} semanas</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono">{settings.fechaInicio} — {settings.fechaFin}</span>
          </div>
        </div>

        {/* Legend & View Mode Switcher */}
        <div className="flex items-center gap-4 flex-wrap">
          <div className="flex items-center gap-3 text-xs text-slate-600 dark:text-slate-300">
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-sm bg-red-500 inline-block" />
              <span>Prioridad Alta</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-sm bg-emerald-500 inline-block" />
              <span>Media / Baja</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-sm border-2 border-amber-400 bg-amber-50 dark:bg-amber-950 inline-block" />
              <span>Ruta Crítica</span>
            </div>
          </div>

          <div className="flex items-center p-0.5 bg-slate-100 dark:bg-slate-800 rounded text-xs">
            <button
              onClick={() => setViewMode('weekly')}
              className={`px-2.5 py-1 rounded font-medium transition-colors ${
                viewMode === 'weekly'
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 shadow-xs'
                  : 'text-slate-500 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              Semanal (S1 - S{settings.totalSemanas})
            </button>
            <button
              onClick={() => setViewMode('daily')}
              className={`px-2.5 py-1 rounded font-medium transition-colors ${
                viewMode === 'daily'
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 shadow-xs'
                  : 'text-slate-500 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              Día a Día (D1 - D{totalDays})
            </button>
          </div>
        </div>
      </div>

      {/* Gantt Timeline Table Container */}
      <div className="overflow-x-auto">
        <div className="min-w-[920px]">
          {/* Table Header */}
          <div className="grid grid-cols-12 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-300">
            {/* Task Info Column */}
            <div className="col-span-5 p-3 flex items-center justify-between border-r border-slate-200 dark:border-slate-800">
              <span>Actividad / Tarea</span>
              <span className="font-mono text-slate-400 font-normal">Fase · Resp · Días</span>
            </div>

            {/* Timeline Columns */}
            {viewMode === 'weekly' ? (
              <div className="col-span-7 grid" style={{ gridTemplateColumns: `repeat(${settings.totalSemanas}, minmax(0, 1fr))` }}>
                {weekRanges.map((w) => (
                  <div
                    key={w.semana}
                    className="p-2 text-center border-r last:border-r-0 border-slate-200 dark:border-slate-800"
                  >
                    <div className="font-bold text-slate-900 dark:text-slate-100">{w.label}</div>
                    <div className="text-[10px] text-slate-500 dark:text-slate-400 font-mono mt-0.5">{w.rango}</div>
                  </div>
                ))}
              </div>
            ) : (
              <div
                className="col-span-7 grid overflow-x-auto"
                style={{ gridTemplateColumns: `repeat(${totalDays}, minmax(24px, 1fr))` }}
              >
                {daysArray.map((day) => (
                  <div
                    key={day}
                    className={`py-2 text-center border-r last:border-r-0 border-slate-200 dark:border-slate-800 text-[10px] font-mono ${
                      day % 5 === 0 ? 'bg-slate-100 dark:bg-slate-800 font-bold' : ''
                    }`}
                  >
                    {day}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Table Rows */}
          <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
            {tasks.map((task) => {
              const isHighPriority = task.prioridad === 'Alta';
              const barColor = isHighPriority
                ? 'bg-red-500 hover:bg-red-600 text-white'
                : 'bg-emerald-600 hover:bg-emerald-700 text-white';

              return (
                <div
                  key={task.id}
                  className={`grid grid-cols-12 transition-colors hover:bg-slate-50/70 dark:hover:bg-slate-800/40 items-center ${
                    task.esCritica ? 'bg-amber-50/20 dark:bg-amber-950/10' : ''
                  }`}
                >
                  {/* Task Name & Metadata */}
                  <div className="col-span-5 p-3 border-r border-slate-200 dark:border-slate-800 flex items-start gap-2.5">
                    <span
                      className={`inline-flex items-center justify-center w-5 h-5 rounded font-mono font-bold text-[11px] shrink-0 mt-0.5 ${
                        task.esCritica
                          ? 'bg-amber-100 dark:bg-amber-900/60 text-amber-800 dark:text-amber-200 border border-amber-300 dark:border-amber-700'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      {task.id}
                    </span>

                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => onSelectTask(task.id)}
                          className="font-medium text-slate-900 dark:text-slate-100 hover:text-red-600 dark:hover:text-red-400 text-left line-clamp-1 transition-colors"
                        >
                          {task.actividad}
                        </button>
                      </div>

                      <div className="flex items-center gap-2 text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                        <span className="font-medium text-slate-700 dark:text-slate-300">{task.fase}</span>
                        <span aria-hidden="true">·</span>
                        <span className="truncate max-w-[140px]" title={task.responsable}>
                          {task.responsable}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span className="font-mono tabular-nums">{task.duracion}d ({task.fechaInicio.slice(0, 5)} - {task.fechaFin.slice(0, 5)})</span>
                        {task.esCritica && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span className="text-amber-600 dark:text-amber-400 font-semibold">Crítica</span>
                          </>
                        )}
                        {task.dependeDe !== '—' && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span className="font-mono text-slate-400">Dep: #{task.dependeDe}</span>
                          </>
                        )}
                      </div>
                    </div>

                    {/* Quick status cycle button */}
                    <button
                      onClick={() => {
                        const nextStatus: Record<Task['estado'], Task['estado']> = {
                          Pendiente: 'En curso',
                          'En curso': 'Completada',
                          Completada: 'Pendiente',
                          Bloqueada: 'En curso',
                        };
                        onUpdateStatus(task.id, nextStatus[task.estado]);
                      }}
                      title={`Estado actual: ${task.estado}. Clic para cambiar.`}
                      className={`p-1 rounded shrink-0 transition-colors ${
                        task.estado === 'Completada'
                          ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300'
                          : task.estado === 'En curso'
                          ? 'bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300'
                          : task.estado === 'Bloqueada'
                          ? 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300'
                          : 'bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400'
                      }`}
                    >
                      {task.estado === 'Completada' ? (
                        <Check className="w-3.5 h-3.5" />
                      ) : (
                        <Clock className="w-3.5 h-3.5" />
                      )}
                    </button>
                  </div>

                  {/* Timeline Bar Section */}
                  {viewMode === 'weekly' ? (
                    <div
                      className="col-span-7 grid h-full py-2 items-center"
                      style={{ gridTemplateColumns: `repeat(${settings.totalSemanas}, minmax(0, 1fr))` }}
                    >
                      {task.semanas.map((isActive, wIdx) => {
                        // Check if this week is the start or end of the task
                        const weekStartDay = wIdx * 5 + 1;
                        const weekEndDay = (wIdx + 1) * 5;
                        const isStart = task.diaInicio >= weekStartDay && task.diaInicio <= weekEndDay;
                        const isEnd = task.diaFin >= weekStartDay && task.diaFin <= weekEndDay;

                        return (
                          <div
                            key={wIdx}
                            className="h-7 px-0.5 flex items-center border-r last:border-r-0 border-slate-100 dark:border-slate-800"
                          >
                            {isActive ? (
                              <div
                                onClick={() => onSelectTask(task.id)}
                                title={`#${task.id} ${task.actividad} | S${wIdx + 1} | Días ${task.diaInicio}-${task.diaFin}`}
                                className={`w-full h-5 rounded-xs flex items-center justify-center font-mono font-bold text-[10px] cursor-pointer shadow-2xs transition-all ${barColor} ${
                                  task.esCritica ? 'ring-1 ring-amber-400/90' : ''
                                } ${isStart ? 'rounded-l' : ''} ${isEnd ? 'rounded-r' : ''}`}
                              >
                                {isStart && <span className="truncate px-1">D{task.diaInicio}</span>}
                                {!isStart && isEnd && <span className="truncate px-1">D{task.diaFin}</span>}
                              </div>
                            ) : null}
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    /* Daily View */
                    <div
                      className="col-span-7 grid h-full py-2 items-center overflow-x-auto"
                      style={{ gridTemplateColumns: `repeat(${totalDays}, minmax(24px, 1fr))` }}
                    >
                      {daysArray.map((day) => {
                        const isDayActive = day >= task.diaInicio && day <= task.diaFin;
                        return (
                          <div
                            key={day}
                            className={`h-7 px-0.5 flex items-center border-r last:border-r-0 border-slate-100 dark:border-slate-800 ${
                              day % 5 === 0 ? 'bg-slate-50/50 dark:bg-slate-800/30' : ''
                            }`}
                          >
                            {isDayActive && (
                              <div
                                onClick={() => onSelectTask(task.id)}
                                title={`#${task.id} ${task.actividad} | Día ${day} (${task.fechaInicio} - ${task.fechaFin})`}
                                className={`w-full h-4 rounded-xs cursor-pointer ${barColor} ${
                                  task.esCritica ? 'ring-1 ring-amber-400' : ''
                                }`}
                              />
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Footer Info Callout */}
      <div className="p-3 bg-slate-50 dark:bg-slate-800/40 border-t border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 dark:text-slate-400 gap-2">
        <div className="flex items-center gap-2">
          <span className="font-semibold text-slate-700 dark:text-slate-300">Regla del Cronograma UTS:</span>
          <span>Rojo = prioridad Alta; Verde = prioridad Media/Baja. Las duraciones se calculan en días hábiles (5 días/semana).</span>
        </div>
        <div className="flex items-center gap-3">
          <span>{tasks.length} actividades planificadas</span>
          <span aria-hidden="true">·</span>
          <span className="font-mono text-slate-700 dark:text-slate-300 font-semibold">{settings.totalSemanas} Semanas Totales</span>
        </div>
      </div>
    </div>
  );
};
