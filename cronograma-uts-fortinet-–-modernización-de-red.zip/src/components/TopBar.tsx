import React from 'react';
import { Download, Sun, Moon, Plus } from 'lucide-react';

interface TopBarProps {
  activeTab: 'gantt' | 'table' | 'kanban' | 'topology' | 'risks';
  setActiveTab: (tab: 'gantt' | 'table' | 'kanban' | 'topology' | 'risks') => void;
  isDark: boolean;
  toggleDark: () => void;
  onOpenNewTask: () => void;
  onExportCSV: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  activeTab,
  setActiveTab,
  isDark,
  toggleDark,
  onOpenNewTask,
  onExportCSV,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8 h-16">
          {/* Zone 1: Single text element wordmark */}
          <div className="flex items-center gap-3 shrink-0">
            <span className="font-bold text-lg text-slate-900 dark:text-slate-100 tracking-tight whitespace-nowrap">
              UTS Red · Fortinet Security Fabric
            </span>
          </div>

          {/* Zone 2: Clean single-line navigation links */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium">
            <button
              onClick={() => setActiveTab('gantt')}
              className={`whitespace-nowrap shrink-0 transition-colors py-1 border-b-2 text-sm ${
                activeTab === 'gantt'
                  ? 'border-red-600 text-red-600 dark:text-red-400 dark:border-red-400 font-semibold'
                  : 'border-transparent text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
              }`}
            >
              Cronograma & Gantt
            </button>
            <button
              onClick={() => setActiveTab('table')}
              className={`whitespace-nowrap shrink-0 transition-colors py-1 border-b-2 text-sm ${
                activeTab === 'table'
                  ? 'border-red-600 text-red-600 dark:text-red-400 dark:border-red-400 font-semibold'
                  : 'border-transparent text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
              }`}
            >
              Matriz Excel
            </button>
            <button
              onClick={() => setActiveTab('kanban')}
              className={`whitespace-nowrap shrink-0 transition-colors py-1 border-b-2 text-sm ${
                activeTab === 'kanban'
                  ? 'border-red-600 text-red-600 dark:text-red-400 dark:border-red-400 font-semibold'
                  : 'border-transparent text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
              }`}
            >
              Tablero Kanban
            </button>
            <button
              onClick={() => setActiveTab('topology')}
              className={`whitespace-nowrap shrink-0 transition-colors py-1 border-b-2 text-sm ${
                activeTab === 'topology'
                  ? 'border-red-600 text-red-600 dark:text-red-400 dark:border-red-400 font-semibold'
                  : 'border-transparent text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
              }`}
            >
              Topología & Requisitos
            </button>
            <button
              onClick={() => setActiveTab('risks')}
              className={`whitespace-nowrap shrink-0 transition-colors py-1 border-b-2 text-sm ${
                activeTab === 'risks'
                  ? 'border-red-600 text-red-600 dark:text-red-400 dark:border-red-400 font-semibold'
                  : 'border-transparent text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
              }`}
            >
              Ruta Crítica & Riesgos
            </button>
          </nav>

          {/* Zone 3: 1 primary action + theme toggle */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={toggleDark}
              aria-label="Cambiar tema claro/oscuro"
              className="p-2 text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-100 rounded-md hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>

            <button
              onClick={onOpenNewTask}
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-md transition-colors whitespace-nowrap shrink-0"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Añadir Tarea</span>
            </button>

            <button
              onClick={onExportCSV}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-red-600 hover:bg-red-700 rounded-md transition-colors shadow-sm whitespace-nowrap shrink-0"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Exportar Excel</span>
            </button>
          </div>
        </div>

        {/* Mobile Navigation Row */}
        <div className="flex md:hidden overflow-x-auto py-2 gap-4 text-xs font-medium border-t border-slate-100 dark:border-slate-800">
          <button
            onClick={() => setActiveTab('gantt')}
            className={`whitespace-nowrap shrink-0 ${
              activeTab === 'gantt' ? 'text-red-600 dark:text-red-400 font-semibold' : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            Cronograma
          </button>
          <button
            onClick={() => setActiveTab('table')}
            className={`whitespace-nowrap shrink-0 ${
              activeTab === 'table' ? 'text-red-600 dark:text-red-400 font-semibold' : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            Matriz Excel
          </button>
          <button
            onClick={() => setActiveTab('kanban')}
            className={`whitespace-nowrap shrink-0 ${
              activeTab === 'kanban' ? 'text-red-600 dark:text-red-400 font-semibold' : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            Kanban
          </button>
          <button
            onClick={() => setActiveTab('topology')}
            className={`whitespace-nowrap shrink-0 ${
              activeTab === 'topology' ? 'text-red-600 dark:text-red-400 font-semibold' : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            Topología
          </button>
          <button
            onClick={() => setActiveTab('risks')}
            className={`whitespace-nowrap shrink-0 ${
              activeTab === 'risks' ? 'text-red-600 dark:text-red-400 font-semibold' : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            Ruta Crítica
          </button>
        </div>
      </div>
    </header>
  );
};
