import React from 'react';
import { Search, RotateCcw, Calendar, Filter, Zap } from 'lucide-react';
import { Phase, Priority, TaskStatus } from '../types/project';

interface FilterBarProps {
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  selectedPhase: string;
  setSelectedPhase: (phase: string) => void;
  selectedPriority: string;
  setSelectedPriority: (priority: string) => void;
  selectedStatus: string;
  setSelectedStatus: (status: string) => void;
  onlyCritical: boolean;
  setOnlyCritical: (crit: boolean) => void;
  startDateInput: string;
  setStartDateInput: (date: string) => void;
  onReset: () => void;
  phases: Phase[];
}

export const FilterBar: React.FC<FilterBarProps> = ({
  searchQuery,
  setSearchQuery,
  selectedPhase,
  setSelectedPhase,
  selectedPriority,
  setSelectedPriority,
  selectedStatus,
  setSelectedStatus,
  onlyCritical,
  setOnlyCritical,
  startDateInput,
  setStartDateInput,
  onReset,
  phases,
}) => {
  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg p-3 space-y-3">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
        {/* Search input */}
        <div className="relative flex-1 min-w-[200px] max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Buscar por actividad, responsable o #..."
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-md focus:outline-none focus:ring-1 focus:ring-red-500 text-slate-900 dark:text-slate-100 placeholder:text-slate-400"
          />
        </div>

        {/* Date Picker & Reset */}
        <div className="flex items-center gap-3 shrink-0 flex-wrap">
          <div className="flex items-center gap-1.5 text-xs text-slate-600 dark:text-slate-400">
            <Calendar className="w-3.5 h-3.5 text-slate-400" />
            <span className="font-medium whitespace-nowrap">Inicio Proyecto:</span>
            <input
              type="date"
              value={startDateInput}
              onChange={(e) => setStartDateInput(e.target.value)}
              className="px-2 py-1 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded text-slate-900 dark:text-slate-100 font-mono"
            />
          </div>

          <button
            onClick={() => setOnlyCritical(!onlyCritical)}
            className={`inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap ${
              onlyCritical
                ? 'bg-amber-500 text-white shadow-sm'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            <span>Ruta Crítica</span>
          </button>

          <button
            onClick={onReset}
            title="Restaurar valores iniciales del Excel UTS"
            className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded transition-colors whitespace-nowrap"
          >
            <RotateCcw className="w-3 h-3" />
            <span>Restablecer</span>
          </button>
        </div>
      </div>

      {/* Segmented Filter Row */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs scrollbar-thin">
        <span className="text-slate-400 dark:text-slate-500 font-medium shrink-0 flex items-center gap-1">
          <Filter className="w-3 h-3" />
          <span>Fase:</span>
        </span>
        <button
          onClick={() => setSelectedPhase('all')}
          className={`px-2.5 py-1 rounded whitespace-nowrap font-medium transition-colors ${
            selectedPhase === 'all'
              ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
          }`}
        >
          Todas
        </button>
        {phases.map((phase) => (
          <button
            key={phase}
            onClick={() => setSelectedPhase(phase)}
            className={`px-2.5 py-1 rounded whitespace-nowrap font-medium transition-colors ${
              selectedPhase === phase
                ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            {phase}
          </button>
        ))}

        <div className="h-4 w-px bg-slate-200 dark:bg-slate-700 mx-1 shrink-0" />

        <span className="text-slate-400 dark:text-slate-500 font-medium shrink-0">Prioridad:</span>
        <select
          value={selectedPriority}
          onChange={(e) => setSelectedPriority(e.target.value)}
          className="px-2 py-0.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded text-slate-800 dark:text-slate-200 text-xs"
        >
          <option value="all">Todas</option>
          <option value="Alta">Alta (Rojo)</option>
          <option value="Media">Media (Verde)</option>
          <option value="Baja">Baja</option>
        </select>

        <span className="text-slate-400 dark:text-slate-500 font-medium shrink-0">Estado:</span>
        <select
          value={selectedStatus}
          onChange={(e) => setSelectedStatus(e.target.value)}
          className="px-2 py-0.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded text-slate-800 dark:text-slate-200 text-xs"
        >
          <option value="all">Todos</option>
          <option value="Pendiente">Pendiente</option>
          <option value="En curso">En curso</option>
          <option value="Completada">Completada</option>
          <option value="Bloqueada">Bloqueada</option>
        </select>
      </div>
    </div>
  );
};
