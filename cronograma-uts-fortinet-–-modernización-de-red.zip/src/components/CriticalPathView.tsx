import React, { useState } from 'react';
import { Task, ProjectSettings } from '../types/project';
import { AlertTriangle, ArrowRight, CheckCircle2, TrendingUp, Sliders, ShieldAlert } from 'lucide-react';
import { recalculateSchedule, parseDateInput, formatDateDMY, getDateForWorkingDay } from '../utils/scheduleCalculator';

interface CriticalPathViewProps {
  tasks: Task[];
  settings: ProjectSettings;
  onSelectTask: (id: number) => void;
  onUpdateDuration: (id: number, newDuration: number) => void;
}

export const CriticalPathView: React.FC<CriticalPathViewProps> = ({
  tasks,
  settings,
  onSelectTask,
  onUpdateDuration,
}) => {
  const [task3Delay, setTask3Delay] = useState<number>(0);

  // Original Task 3
  const task3 = tasks.find((t) => t.id === 3);
  const baseTask3Duration = 3;

  // Simulate schedule when task 3 has delay
  const simulatedTasks = tasks.map((t) => {
    if (t.id === 3) {
      return { ...t, duracion: baseTask3Duration + task3Delay };
    }
    return { ...t };
  });

  const { settings: simulatedSettings, recalculatedTasks } = recalculateSchedule(
    simulatedTasks,
    settings.fechaInicio
  );

  const simulatedGoLiveTask = recalculatedTasks.find((t) => t.id === 11);
  const originalGoLiveTask = tasks.find((t) => t.id === 11);

  return (
    <div className="space-y-6">
      {/* Critical Path Header */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg p-5">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="font-semibold text-lg text-slate-900 dark:text-slate-100">
                Análisis de Ruta Crítica & Dependencias
              </span>
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-400 mt-1 max-w-3xl">
              Cálculo del método de ruta crítica (CPM). Las tareas con holgura igual a 0 días determinan de manera estricta la fecha final del Go-Live. Cualquier retraso en la ruta crítica atrasa el proyecto completo.
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs font-mono">
            <span className="px-3 py-1.5 bg-amber-50 dark:bg-amber-950/60 text-amber-800 dark:text-amber-200 rounded border border-amber-300 dark:border-amber-800 font-bold">
              7 Tareas en Ruta Crítica (0d Holgura)
            </span>
          </div>
        </div>
      </div>

      {/* Task #3 Highlight and What-If Simulator */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg p-5">
        <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800 mb-4">
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-red-600 dark:text-red-400" />
            <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
              Simulador de Impacto: Actividad #3 (Ficha Técnica y Dimensionamiento)
            </h3>
          </div>
          <span className="text-xs font-mono text-red-600 dark:text-red-400 font-bold">
            Prioridad Alta · Nodo Clave
          </span>
        </div>

        <p className="text-xs text-slate-600 dark:text-slate-400 mb-4">
          El cronograma oficial de UTS resalta la Tarea #3 como la más crítica del proyecto porque valida los 5.000 usuarios concurrentes y dimensiona el hardware Fortinet. De ella dependen la orden de compra (#4), la adecuación de cableado (#5) y la instalación (#6).
        </p>

        {/* Simulation Slider Control */}
        <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-lg border border-slate-200 dark:border-slate-700 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <div className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                Simular retraso o ampliación de duración en Tarea #3:
              </div>
              <div className="text-[11px] text-slate-500">
                Duración base: 3 días hábiles | Duración simulada:{' '}
                <span className="font-mono font-bold text-slate-900 dark:text-slate-100">
                  {baseTask3Duration + task3Delay} días hábiles
                </span>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <input
                type="range"
                min="0"
                max="15"
                value={task3Delay}
                onChange={(e) => setTask3Delay(parseInt(e.target.value, 10))}
                className="w-44 accent-red-600"
              />
              <span className="font-mono font-bold text-xs px-2 py-0.5 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded min-w-[50px] text-center">
                +{task3Delay} d
              </span>
              {task3Delay > 0 && (
                <button
                  onClick={() => setTask3Delay(0)}
                  className="text-xs text-slate-500 hover:text-slate-900 dark:hover:text-slate-100 underline"
                >
                  Reiniciar
                </button>
              )}
            </div>
          </div>

          {/* Simulation Outcome Comparison */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 text-xs">
            <div className="p-3 bg-white dark:bg-slate-900 rounded border border-slate-200 dark:border-slate-800">
              <div className="text-slate-400 text-[10px]">DURACIÓN TOTAL SIMULADA</div>
              <div className="text-lg font-bold font-mono text-slate-900 dark:text-slate-100 mt-1">
                {simulatedSettings.totalDiasHabiles} días hábiles
              </div>
              <div className="text-[11px] text-slate-500 mt-0.5">
                {simulatedSettings.totalSemanas} semanas ({task3Delay > 0 ? `+${task3Delay} días de atraso` : 'Sin retraso'})
              </div>
            </div>

            <div className="p-3 bg-white dark:bg-slate-900 rounded border border-slate-200 dark:border-slate-800">
              <div className="text-slate-400 text-[10px]">FECHA GO-LIVE SIMULADA</div>
              <div className="text-lg font-bold font-mono text-red-600 dark:text-red-400 mt-1">
                {simulatedGoLiveTask?.fechaFin}
              </div>
              <div className="text-[11px] text-slate-500 mt-0.5">
                Fecha base: {originalGoLiveTask?.fechaFin}
              </div>
            </div>

            <div className="p-3 bg-white dark:bg-slate-900 rounded border border-slate-200 dark:border-slate-800">
              <div className="text-slate-400 text-[10px]">ACCIONES RECOMENDADAS</div>
              <div className="text-xs font-semibold text-slate-800 dark:text-slate-200 mt-1">
                {task3Delay === 0
                  ? 'Plan nominal UTS en regla.'
                  : task3Delay <= 3
                  ? 'Acelerar orden de compra #4 en paralelo.'
                  : 'Riesgo Alto: Requiere horas extras en cableado #5.'}
              </div>
              {task3Delay > 0 && (
                <button
                  onClick={() => onUpdateDuration(3, baseTask3Duration + task3Delay)}
                  className="mt-2 text-[10px] font-semibold text-red-600 dark:text-red-400 hover:underline"
                >
                  Aplicar esta duración al cronograma principal →
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Dependency Flow Chain */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg p-5">
        <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100 mb-3">
          Cadena de Nodos & Ruta Crítica (CPM)
        </h3>
        <p className="text-xs text-slate-500 mb-4">
          La secuencia resaltada en rojo representa el camino crítico ininterrumpido. Las bifurcaciones en verde tienen margen de holgura.
        </p>

        {/* Visual Sequential Flow */}
        <div className="space-y-4 text-xs font-mono">
          {/* Phase 1: Análisis */}
          <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded border border-slate-200 dark:border-slate-800">
            <div className="text-[10px] font-sans font-bold text-slate-400 uppercase tracking-wider mb-2">
              Fase 1: Análisis (Día 1 a Día 8)
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <div className="px-2.5 py-1.5 bg-red-100 dark:bg-red-950/80 text-red-800 dark:text-red-200 border border-red-300 dark:border-red-800 rounded">
                #1 Inventario & Cobertura (5d) · Crítica
              </div>
              <span className="text-slate-400">+</span>
              <div className="px-2.5 py-1.5 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 rounded">
                #2 Validar Requisitos (3d, Holgura 2d)
              </div>
              <ArrowRight className="w-4 h-4 text-red-500" />
              <div className="px-3 py-1.5 bg-red-600 text-white font-bold rounded shadow-xs">
                #3 Verificar Fortinet 5000 users & Sizing (3d) · NODO CRÍTICO
              </div>
            </div>
          </div>

          {/* Phase 2: Instalación */}
          <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded border border-slate-200 dark:border-slate-800">
            <div className="text-[10px] font-sans font-bold text-slate-400 uppercase tracking-wider mb-2">
              Fase 2: Instalación (Día 9 a Día 23)
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <div className="px-2.5 py-1.5 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 rounded">
                #4 Orden de Compra (4d, Holgura 4d)
              </div>
              <span className="text-slate-400">vs</span>
              <div className="px-2.5 py-1.5 bg-red-100 dark:bg-red-950/80 text-red-800 dark:text-red-200 border border-red-300 dark:border-red-800 rounded">
                #5 Cableado Estructurado (8d) · Crítica
              </div>
              <ArrowRight className="w-4 h-4 text-red-500" />
              <div className="px-3 py-1.5 bg-red-600 text-white font-bold rounded shadow-xs">
                #6 Instalar FortiGate HA, Switches & APs (7d) · Crítica
              </div>
            </div>
          </div>

          {/* Phase 3: Migración & Configuración */}
          <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded border border-slate-200 dark:border-slate-800">
            <div className="text-[10px] font-sans font-bold text-slate-400 uppercase tracking-wider mb-2">
              Fase 3: Migración & Configuración (Día 24 a Día 29)
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <div className="px-2.5 py-1.5 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 rounded">
                #7 Migrar Usuarios y Servicios (5d, Holgura 1d)
              </div>
              <span className="text-slate-400">vs</span>
              <div className="px-2.5 py-1.5 bg-red-100 dark:bg-red-950/80 text-red-800 dark:text-red-200 border border-red-300 dark:border-red-800 rounded">
                #8 Políticas Firewall, Wifi & HA (6d) · Crítica
              </div>
            </div>
          </div>

          {/* Phase 4: Pruebas & Go-Live */}
          <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded border border-slate-200 dark:border-slate-800">
            <div className="text-[10px] font-sans font-bold text-slate-400 uppercase tracking-wider mb-2">
              Fase 4: Pruebas, Capacitación y Go-Live (Día 30 a Día 39)
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <div className="px-3 py-1.5 bg-red-600 text-white font-bold rounded shadow-xs">
                #9 Pruebas de Carga 5000 users & 99.5% (5d) · Crítica
              </div>
              <span className="text-slate-400">+</span>
              <div className="px-2.5 py-1.5 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 rounded">
                #10 Capacitación Técnica (4d, Holgura 1d)
              </div>
              <ArrowRight className="w-4 h-4 text-red-500" />
              <div className="px-3 py-1.5 bg-emerald-600 text-white font-bold rounded shadow-xs">
                #11 Aceptación Formal & Puesta en Producción Go-Live (5d)
              </div>
              <span className="text-slate-400">+</span>
              <div className="px-2.5 py-1.5 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 rounded">
                #12 Informe de Inventario (3d, Holgura 2d)
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Slack & Margin Breakdown Table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg p-5">
        <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100 mb-2">
          Tabla Detallada de Holguras y Margen por Actividad
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-700 text-slate-500 font-medium">
                <th className="pb-2">#</th>
                <th className="pb-2">Actividad</th>
                <th className="pb-2 text-right">Duración</th>
                <th className="pb-2 text-center">Dependencias</th>
                <th className="pb-2 text-center font-mono">Días Inicio - Fin</th>
                <th className="pb-2 text-right font-mono">Holgura Libre</th>
                <th className="pb-2 text-center">Estado Crítico</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-mono">
              {tasks.map((task) => (
                <tr key={task.id} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/30">
                  <td className="py-2.5 font-bold text-slate-700 dark:text-slate-300">#{task.id}</td>
                  <td className="py-2.5 font-sans font-medium text-slate-900 dark:text-slate-100 max-w-sm truncate">
                    {task.actividad}
                  </td>
                  <td className="py-2.5 text-right">{task.duracion}d</td>
                  <td className="py-2.5 text-center text-slate-500">{task.dependeDe}</td>
                  <td className="py-2.5 text-center">
                    D{task.diaInicio} - D{task.diaFin}
                  </td>
                  <td className="py-2.5 text-right font-bold">
                    {task.holgura === 0 ? (
                      <span className="text-amber-600 dark:text-amber-400">0 días</span>
                    ) : (
                      <span className="text-emerald-600 dark:text-emerald-400">+{task.holgura} días</span>
                    )}
                  </td>
                  <td className="py-2.5 text-center font-sans font-semibold">
                    {task.esCritica ? (
                      <span className="text-xs text-red-600 dark:text-red-400">Ruta Crítica</span>
                    ) : (
                      <span className="text-xs text-slate-400">Flexible</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
