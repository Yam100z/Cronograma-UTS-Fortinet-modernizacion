import React from 'react';
import { Task, TaskStatus } from '../types/project';
import { X, Calendar, Clock, AlertTriangle, CheckCircle2, User, Link as LinkIcon, Edit3 } from 'lucide-react';

interface TaskDetailDrawerProps {
  task: Task | null;
  onClose: () => void;
  onEdit: (task: Task) => void;
  onUpdateStatus: (id: number, status: TaskStatus) => void;
  allTasks: Task[];
}

export const TaskDetailDrawer: React.FC<TaskDetailDrawerProps> = ({
  task,
  onClose,
  onEdit,
  onUpdateStatus,
  allTasks,
}) => {
  if (!task) return null;

  // Find predecessor and successor tasks
  const predecessorIds =
    task.dependeDe && task.dependeDe !== '—'
      ? task.dependeDe
          .split(',')
          .map((s) => parseInt(s.trim(), 10))
          .filter((n) => !isNaN(n))
      : [];

  const predecessors = allTasks.filter((t) => predecessorIds.includes(t.id));
  const successors = allTasks.filter((t) => {
    if (!t.dependeDe || t.dependeDe === '—') return false;
    const deps = t.dependeDe
      .split(',')
      .map((s) => parseInt(s.trim(), 10))
      .filter((n) => !isNaN(n));
    return deps.includes(task.id);
  });

  return (
    <div className="fixed inset-y-0 right-0 z-40 w-full max-w-md bg-white dark:bg-slate-900 border-l border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col transition-all">
      {/* Header */}
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="font-mono font-bold text-xs px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200">
            Tarea #{task.id}
          </span>
          <span className="text-xs font-semibold text-slate-500">{task.fase}</span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onEdit(task)}
            className="p-1.5 text-slate-500 hover:text-slate-900 dark:hover:text-slate-100 rounded hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title="Editar actividad"
          >
            <Edit3 className="w-4 h-4" />
          </button>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="p-5 flex-1 overflow-y-auto space-y-5 text-xs">
        {/* Title */}
        <div>
          <h2 className="text-base font-bold text-slate-900 dark:text-slate-100 leading-snug">
            {task.actividad}
          </h2>
          {task.esCritica && (
            <div className="mt-2 inline-flex items-center gap-1.5 px-2.5 py-1 bg-amber-50 dark:bg-amber-950/60 text-amber-800 dark:text-amber-200 rounded border border-amber-300 dark:border-amber-800 font-semibold text-[11px]">
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>Actividad en Ruta Crítica (0 días de holgura)</span>
            </div>
          )}
        </div>

        {/* Status Switcher Bar */}
        <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-lg border border-slate-200 dark:border-slate-700 space-y-2">
          <span className="text-slate-500 font-medium">Estado de Ejecución:</span>
          <div className="grid grid-cols-2 gap-1.5">
            {(['Pendiente', 'En curso', 'Completada', 'Bloqueada'] as TaskStatus[]).map((st) => (
              <button
                key={st}
                onClick={() => onUpdateStatus(task.id, st)}
                className={`py-1.5 px-2 rounded font-medium text-xs transition-colors text-center ${
                  task.estado === st
                    ? st === 'Completada'
                      ? 'bg-emerald-600 text-white font-bold'
                      : st === 'En curso'
                      ? 'bg-blue-600 text-white font-bold'
                      : st === 'Bloqueada'
                      ? 'bg-rose-600 text-white font-bold'
                      : 'bg-slate-800 text-white dark:bg-slate-200 dark:text-slate-900 font-bold'
                    : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100'
                }`}
              >
                {st}
              </button>
            ))}
          </div>
        </div>

        {/* Schedule & Days Details */}
        <div className="grid grid-cols-2 gap-3 font-mono">
          <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded border border-slate-200 dark:border-slate-800">
            <div className="text-slate-400 text-[10px] font-sans">DURACIÓN</div>
            <div className="text-base font-bold text-slate-900 dark:text-slate-100 mt-0.5">
              {task.duracion} días hábiles
            </div>
            <div className="text-[11px] text-slate-500 mt-1">Días D{task.diaInicio} a D{task.diaFin}</div>
          </div>

          <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded border border-slate-200 dark:border-slate-800">
            <div className="text-slate-400 text-[10px] font-sans">HOLGURA / MARGEN</div>
            <div
              className={`text-base font-bold mt-0.5 ${
                task.holgura === 0
                  ? 'text-amber-600 dark:text-amber-400'
                  : 'text-emerald-600 dark:text-emerald-400'
              }`}
            >
              {task.holgura === 0 ? '0 días' : `+${task.holgura} días`}
            </div>
            <div className="text-[11px] text-slate-500 mt-1">
              {task.holgura === 0 ? 'Sin margen de holgura' : 'Retraso amortizable'}
            </div>
          </div>
        </div>

        {/* Dates */}
        <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded border border-slate-200 dark:border-slate-800 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-slate-500">Fecha de Inicio:</span>
            <span className="font-mono font-bold text-slate-900 dark:text-slate-100">
              {task.fechaInicio}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-slate-500">Fecha de Fin estimada:</span>
            <span className="font-mono font-bold text-slate-900 dark:text-slate-100">
              {task.fechaFin}
            </span>
          </div>
          <div className="flex items-center justify-between pt-1 border-t border-slate-200 dark:border-slate-700">
            <span className="text-slate-500">Prioridad asignada:</span>
            <span
              className={`font-semibold ${
                task.prioridad === 'Alta'
                  ? 'text-red-600 dark:text-red-400'
                  : 'text-emerald-600 dark:text-emerald-400'
              }`}
            >
              {task.prioridad}
            </span>
          </div>
        </div>

        {/* Responsible */}
        <div>
          <span className="text-slate-400 uppercase font-semibold text-[10px] tracking-wider block mb-1">
            Responsable del Proyecto UTS
          </span>
          <div className="p-2.5 bg-slate-50 dark:bg-slate-800/40 rounded border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-200 flex items-center gap-2">
            <User className="w-4 h-4 text-slate-400" />
            <span className="font-medium">{task.responsable}</span>
          </div>
        </div>

        {/* Dependencies (Predecessors) */}
        <div>
          <span className="text-slate-400 uppercase font-semibold text-[10px] tracking-wider block mb-1">
            Predecesores (Depende de)
          </span>
          {predecessors.length === 0 ? (
            <div className="text-slate-400 italic">No tiene predecesores (Inicia en Día 1).</div>
          ) : (
            <div className="space-y-1.5">
              {predecessors.map((p) => (
                <div
                  key={p.id}
                  className="p-2 bg-slate-50 dark:bg-slate-800/40 rounded border border-slate-200 dark:border-slate-800 text-[11px] flex items-center justify-between"
                >
                  <span className="font-medium text-slate-800 dark:text-slate-200 truncate pr-2">
                    #{p.id} {p.actividad}
                  </span>
                  <span className="font-mono text-slate-400 shrink-0">Fin: D{p.diaFin}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Successors (Dependen de esta tarea) */}
        <div>
          <span className="text-slate-400 uppercase font-semibold text-[10px] tracking-wider block mb-1">
            Sucesores (Actividades que dependen de esta tarea)
          </span>
          {successors.length === 0 ? (
            <div className="text-slate-400 italic">No tiene tareas sucesoras pendientes.</div>
          ) : (
            <div className="space-y-1.5">
              {successors.map((s) => (
                <div
                  key={s.id}
                  className="p-2 bg-slate-50 dark:bg-slate-800/40 rounded border border-slate-200 dark:border-slate-800 text-[11px] flex items-center justify-between"
                >
                  <span className="font-medium text-slate-800 dark:text-slate-200 truncate pr-2">
                    #{s.id} {s.actividad}
                  </span>
                  <span className="font-mono text-slate-400 shrink-0">Inicio: D{s.diaInicio}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Notes */}
        {task.notas && (
          <div>
            <span className="text-slate-400 uppercase font-semibold text-[10px] tracking-wider block mb-1">
              Notas Técnicas & Alcance
            </span>
            <p className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 leading-relaxed">
              {task.notas}
            </p>
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="p-4 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
        <button
          onClick={() => onEdit(task)}
          className="px-3 py-1.5 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded font-medium text-xs hover:bg-slate-800 dark:hover:bg-slate-100 transition-colors"
        >
          Editar Información
        </button>
        <button
          onClick={onClose}
          className="px-3 py-1.5 text-slate-600 dark:text-slate-400 hover:text-slate-900 text-xs"
        >
          Cerrar
        </button>
      </div>
    </div>
  );
};
