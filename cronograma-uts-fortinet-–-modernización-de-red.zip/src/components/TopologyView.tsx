import React from 'react';
import { Shield, Server, Wifi, Cpu, Layers, CheckCircle2, FileText, Network, Check } from 'lucide-react';
import { FORTINET_COMPONENTS, REQUIREMENTS_MATRIX } from '../data/initialData';

export const TopologyView: React.FC = () => {
  return (
    <div className="space-y-6">
      {/* Overview Banner */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg p-5">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="font-semibold text-lg text-slate-900 dark:text-slate-100">
                Arquitectura Fortinet Security Fabric – UTS
              </span>
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-400 mt-1 max-w-3xl">
              Diseño de infraestructura de red unificada de alta resiliencia para las sedes de las Unidades Tecnológicas de Santander (UTS). Integración integral de capa de seguridad, switching PoE y acceso inalámbrico Wi-Fi 6 bajo administración centralizada.
            </p>
          </div>

          <div className="flex items-center gap-4 text-xs font-mono">
            <div className="p-3 bg-slate-50 dark:bg-slate-800/80 rounded border border-slate-200 dark:border-slate-700">
              <div className="text-slate-400 text-[10px]">CAPACIDAD OBJETIVO</div>
              <div className="text-base font-bold text-slate-900 dark:text-slate-100">5.000 usuarios</div>
            </div>
            <div className="p-3 bg-slate-50 dark:bg-slate-800/80 rounded border border-slate-200 dark:border-slate-700">
              <div className="text-slate-400 text-[10px]">DISPONIBILIDAD SLA</div>
              <div className="text-base font-bold text-emerald-600 dark:text-emerald-400">99.5 % Uptime</div>
            </div>
          </div>
        </div>
      </div>

      {/* Interactive Topology Diagram Visualizer */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg p-5">
        <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-100 dark:border-slate-800">
          <div>
            <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
              Esquema de Red & Conectividad del Campus
            </h3>
            <span className="text-xs text-slate-500">
              Topología lógica jerárquica con redundancia de hardware en núcleo y enlaces de fibra
            </span>
          </div>
          <span className="text-xs font-mono text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950 px-2 py-0.5 rounded border border-emerald-200 dark:border-emerald-800">
            Cluster HA Activo / Pasivo
          </span>
        </div>

        {/* Visual Diagram */}
        <div className="relative p-6 bg-slate-50/70 dark:bg-slate-950/40 rounded-lg border border-slate-200 dark:border-slate-800 space-y-6">
          {/* Level 1: Internet & WAN */}
          <div className="flex justify-center">
            <div className="px-6 py-2 bg-slate-800 text-white rounded-md shadow-xs text-xs flex items-center gap-2">
              <Network className="w-4 h-4 text-sky-400" />
              <span className="font-semibold">Enlaces WAN Redundantes (ISP 1 + ISP 2 / RENATA)</span>
            </div>
          </div>

          <div className="flex justify-center">
            <div className="w-0.5 h-6 bg-slate-300 dark:bg-slate-700" />
          </div>

          {/* Level 2: Core Firewall Cluster */}
          <div className="max-w-2xl mx-auto p-4 bg-red-50/60 dark:bg-red-950/30 border border-red-200 dark:border-red-900/60 rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-red-600 dark:text-red-400" />
                <span className="font-bold text-xs text-red-950 dark:text-red-200">
                  NÚCLEO Y PERÍMETRO: FortiGate Clúster de Alta Disponibilidad (HA)
                </span>
              </div>
              <span className="text-[10px] font-mono text-red-700 dark:text-red-300">
                Sincronización Heartbeat &lt; 1s
              </span>
            </div>
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-2 bg-white dark:bg-slate-800 rounded border border-red-100 dark:border-red-900/40">
                <div className="font-semibold text-slate-800 dark:text-slate-200">FortiGate Principal</div>
                <div className="text-[11px] text-slate-500 mt-0.5">Enrutamiento VLANs, UTM, Inspección SSL</div>
              </div>
              <div className="p-2 bg-white dark:bg-slate-800 rounded border border-red-100 dark:border-red-900/40">
                <div className="font-semibold text-slate-800 dark:text-slate-200">FortiGate de Respaldo</div>
                <div className="text-[11px] text-slate-500 mt-0.5">Espejo en caliente (Hot-Standby automático)</div>
              </div>
            </div>
          </div>

          <div className="flex justify-center">
            <div className="w-0.5 h-6 bg-slate-300 dark:bg-slate-700" />
          </div>

          {/* Level 3: Distribution & Access Switches */}
          <div className="max-w-3xl mx-auto p-4 bg-blue-50/60 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-900/60 rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <Server className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                <span className="font-bold text-xs text-blue-950 dark:text-blue-200">
                  DISTRIBUCIÓN Y ACCESO: FortiSwitch PoE+ en Sedes UTS (Enlace FortiLink)
                </span>
              </div>
              <span className="text-[10px] font-mono text-blue-700 dark:text-blue-300">
                Troncales de Fibra 10GbE
              </span>
            </div>
            <div className="grid grid-cols-3 gap-2.5 text-xs">
              <div className="p-2 bg-white dark:bg-slate-800 rounded border border-blue-100 dark:border-blue-900/40">
                <div className="font-semibold text-slate-800 dark:text-slate-200">Sede Central - Torre A</div>
                <div className="text-[11px] text-slate-500 mt-0.5">Switch Core + Distribución</div>
              </div>
              <div className="p-2 bg-white dark:bg-slate-800 rounded border border-blue-100 dark:border-blue-900/40">
                <div className="font-semibold text-slate-800 dark:text-slate-200">Sede Central - Torre B</div>
                <div className="text-[11px] text-slate-500 mt-0.5">Acceso Aulas y Laboratorios</div>
              </div>
              <div className="p-2 bg-white dark:bg-slate-800 rounded border border-blue-100 dark:border-blue-900/40">
                <div className="font-semibold text-slate-800 dark:text-slate-200">Sedes Regionales UTS</div>
                <div className="text-[11px] text-slate-500 mt-0.5">Switches de Acceso PoE+</div>
              </div>
            </div>
          </div>

          <div className="flex justify-center">
            <div className="w-0.5 h-6 bg-slate-300 dark:bg-slate-700" />
          </div>

          {/* Level 4: Wireless & Endpoints */}
          <div className="max-w-3xl mx-auto p-4 bg-emerald-50/60 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-900/60 rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <Wifi className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                <span className="font-bold text-xs text-emerald-950 dark:text-emerald-200">
                  COBERTURA WIFI CAMPUS: FortiAP Wi-Fi 6 de Alta Densidad
                </span>
              </div>
              <span className="text-[10px] font-mono text-emerald-700 dark:text-emerald-300">
                5000 Clientes Concurrentes
              </span>
            </div>
            <div className="grid grid-cols-4 gap-2 text-center text-xs">
              <div className="p-2 bg-white dark:bg-slate-800 rounded border border-emerald-100 dark:border-emerald-900/40">
                <div className="font-semibold text-slate-800 dark:text-slate-200">Aulas & Edificios</div>
                <div className="text-[10px] text-slate-500">SSID UTS-Estudiantes</div>
              </div>
              <div className="p-2 bg-white dark:bg-slate-800 rounded border border-emerald-100 dark:border-emerald-900/40">
                <div className="font-semibold text-slate-800 dark:text-slate-200">Biblioteca & Salas</div>
                <div className="text-[10px] text-slate-500">SSID UTS-Docentes</div>
              </div>
              <div className="p-2 bg-white dark:bg-slate-800 rounded border border-emerald-100 dark:border-emerald-900/40">
                <div className="font-semibold text-slate-800 dark:text-slate-200">Oficinas Admin</div>
                <div className="text-[10px] text-slate-500">SSID UTS-Admin (802.1X)</div>
              </div>
              <div className="p-2 bg-white dark:bg-slate-800 rounded border border-emerald-100 dark:border-emerald-900/40">
                <div className="font-semibold text-slate-800 dark:text-slate-200">Plazoletas & Zonas</div>
                <div className="text-[10px] text-slate-500">Portal Cautivo Visitas</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Equipment Specs Table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg p-5">
        <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100 mb-3">
          Componentes Fortinet Dimensionados (Tarea #3 y #6)
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-700 text-slate-500">
                <th className="pb-2 font-medium">Elemento</th>
                <th className="pb-2 font-medium">Modelo Estimado</th>
                <th className="pb-2 font-medium">Rol en UTS</th>
                <th className="pb-2 font-medium">Capacidad</th>
                <th className="pb-2 font-medium">Redundancia</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {FORTINET_COMPONENTS.map((comp, idx) => (
                <tr key={idx} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30">
                  <td className="py-2.5 font-semibold text-slate-900 dark:text-slate-100">{comp.nombre}</td>
                  <td className="py-2.5 font-mono text-slate-700 dark:text-slate-300">{comp.modelo}</td>
                  <td className="py-2.5 text-slate-600 dark:text-slate-400 max-w-xs">{comp.rol}</td>
                  <td className="py-2.5 text-slate-700 dark:text-slate-300">{comp.capacidad}</td>
                  <td className="py-2.5 text-emerald-600 dark:text-emerald-400 font-medium">{comp.redundancia}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* RF vs RNF Requirements Matrix (from Task #2) */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg p-5">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
            Matriz de Requisitos RF / RNF (Tarea #2)
          </h3>
          <span className="text-xs text-slate-500">Validada y clasificada para el proyecto UTS</span>
        </div>
        <div className="space-y-2">
          {REQUIREMENTS_MATRIX.map((req, idx) => (
            <div
              key={idx}
              className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded border border-slate-200 dark:border-slate-700/80 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs"
            >
              <div className="flex items-start gap-2.5">
                <span
                  className={`font-mono font-bold text-[10px] px-1.5 py-0.5 rounded ${
                    req.tipo === 'RF'
                      ? 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-200'
                      : 'bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-200'
                  }`}
                >
                  {req.tipo}
                </span>
                <div>
                  <div className="font-semibold text-slate-900 dark:text-slate-100">{req.categoria}</div>
                  <div className="text-slate-600 dark:text-slate-400 mt-0.5">{req.descripcion}</div>
                </div>
              </div>

              <div className="text-right shrink-0">
                <div className="font-medium text-slate-800 dark:text-slate-200">{req.meta}</div>
                <div className="text-[11px] text-slate-500 font-mono mt-0.5">{req.verificacion}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
