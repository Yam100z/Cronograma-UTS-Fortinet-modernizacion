import React from 'react';
import { Calendar, Clock, AlertTriangle, CheckCircle2, ShieldCheck, Users } from 'lucide-react';
import { Task, ProjectSettings } from '../types/project';

interface KPISummaryProps {
  tasks: Task[];
  settings: ProjectSettings;
  onSelectTask?: (id: number) => void;
}

export const KPISummary: React.FC<KPISummaryProps> = ({ tasks, settings, onSelectTask }) => {
  const totalTasks = tasks.length;
  const completedTasks = tasks.filter((t) => t.estado === 'Completada').length;
  const inProgressTasks = tasks.filter((t) => t.estado === 'En curso').length;
  const criticalTasks = tasks.filter((t) => t.esCritica).length;
  const highPriorityTasks = tasks.filter((t) => t.prioridad === 'Alta').length;

  // Calculate weighted progress
  const totalDuration = tasks.reduce((sum, t) => sum + t.duracion, 0);
  const completedDuration = tasks.reduce((sum, t) => {
    if (t.estado === 'Completada') return sum + t.duracion;
    if (t.estado === 'En curso') return sum + t.duracion * 0.5;
    return sum;
  }, 0);
  const progressPercent = totalDuration > 0 ? Math.round((completedDuration / totalDuration) * 100) : 0;

  return (
    <div className="space-y-4">
      {/* KPI Cards Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-3">
        {/* Card 1: Total Duration */}
        <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg">
          <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
            <Clock className="w-3.5 h-3.5" />
            <span>Duración Total</span>
          </div>
          <div className="mt-2 flex items-baseline gap-1.5">
            <span className="text-2xl font-bold tracking-tight text-slate-900 dark:text-slate-100 tabular-nums">
              {settings.totalDiasHabiles}
            </span>
            <span className="text-xs text-slate-500 dark:text-slate-400">días hábiles</span>
          </div>
          <div className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            <span>{settings.totalSemanas} semanas</span>
            <span aria-hidden="true"> · </span>
            <span>{settings.diasPorSemana} d/sem</span>
          </div>
        </div>

        {/* Card 2: Critical Path */}
        <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg">
          <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
            <AlertTriangle className="w-3.5 h-3.5 text-amber-500" />
            <span>Ruta Crítica</span>
          </div>
          <div className="mt-2 flex items-baseline gap-1.5">
            <span className="text-2xl font-bold tracking-tight text-slate-900 dark:text-slate-100 tabular-nums">
              {criticalTasks}
            </span>
            <span className="text-xs text-slate-500 dark:text-slate-400">/ {totalTasks} tareas</span>
          </div>
          <div className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            <span>0 días holgura</span>
            <span aria-hidden="true"> · </span>
            <span className="text-amber-600 dark:text-amber-400">impacto directo</span>
          </div>
        </div>

        {/* Card 3: Priority Alta */}
        <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg">
          <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
            <ShieldCheck className="w-3.5 h-3.5 text-red-500" />
            <span>Prioridad Alta</span>
          </div>
          <div className="mt-2 flex items-baseline gap-1.5">
            <span className="text-2xl font-bold tracking-tight text-red-600 dark:text-red-400 tabular-nums">
              {highPriorityTasks}
            </span>
            <span className="text-xs text-slate-500 dark:text-slate-400">actividades</span>
          </div>
          <div className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            <span>Core & Seguridad</span>
            <span aria-hidden="true"> · </span>
            <span>Fortinet Fabric</span>
          </div>
        </div>

        {/* Card 4: Progress */}
        <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg">
          <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
            <span>Progreso Ponderado</span>
          </div>
          <div className="mt-2 flex items-baseline gap-1.5">
            <span className="text-2xl font-bold tracking-tight text-slate-900 dark:text-slate-100 tabular-nums">
              {progressPercent}%
            </span>
            <span className="text-xs text-slate-500 dark:text-slate-400">completado</span>
          </div>
          <div className="mt-1.5 w-full bg-slate-100 dark:bg-slate-800 rounded-full h-1.5 overflow-hidden">
            <div
              className="bg-emerald-500 h-1.5 rounded-full transition-all duration-300"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>

        {/* Card 5: UTS Capacity Goals */}
        <div className="col-span-2 sm:col-span-1 p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg">
          <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
            <Users className="w-3.5 h-3.5 text-blue-500" />
            <span>Objetivo UTS</span>
          </div>
          <div className="mt-2 flex items-baseline gap-1.5">
            <span className="text-2xl font-bold tracking-tight text-slate-900 dark:text-slate-100 tabular-nums">
              5.000
            </span>
            <span className="text-xs text-slate-500 dark:text-slate-400">usuarios</span>
          </div>
          <div className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            <span>SLA 99.5%</span>
            <span aria-hidden="true"> · </span>
            <span className="text-emerald-600 dark:text-emerald-400 font-medium">HA Redundante</span>
          </div>
        </div>
      </div>

      {/* Critical Activity Banner (from Excel notes) */}
      <div className="p-3.5 bg-red-50/80 dark:bg-red-950/30 border border-red-200 dark:border-red-900/60 rounded-lg flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
        <div className="flex items-start gap-2.5">
          <AlertTriangle className="w-4 h-4 text-red-600 dark:text-red-400 shrink-0 mt-0.5" />
          <div>
            <span className="font-semibold text-red-900 dark:text-red-200">
              Actividad más crítica (Prioridad Alta): #3 – Verificar capacidad de 5.000 usuarios y dimensionar equipos.
            </span>
            <p className="text-red-700 dark:text-red-300 mt-0.5">
              De ella dependen la aprobación de compras (#4), la adecuación del cableado estructurado (#5) y la instalación principal (#6).
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3 shrink-0 self-end md:self-center">
          <div className="text-right text-slate-500 dark:text-slate-400">
            <span className="font-mono tabular-nums text-slate-900 dark:text-slate-100 font-semibold">
              {settings.fechaInicio}
            </span>
            <span aria-hidden="true"> al </span>
            <span className="font-mono tabular-nums text-slate-900 dark:text-slate-100 font-semibold">
              {settings.fechaFin}
            </span>
          </div>
          {onSelectTask && (
            <button
              onClick={() => onSelectTask(3)}
              className="px-2.5 py-1 font-medium bg-red-600 text-white rounded hover:bg-red-700 transition-colors whitespace-nowrap"
            >
              Ver Tarea #3
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
