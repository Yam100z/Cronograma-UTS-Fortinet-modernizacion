import React from 'react';
import { Task, TaskStatus } from '../types/project';
import { Clock, CheckCircle2, AlertCircle, ArrowRight, ArrowLeft } from 'lucide-react';

interface KanbanViewProps {
  tasks: Task[];
  onUpdateStatus: (id: number, status: TaskStatus) => void;
  onSelectTask: (id: number) => void;
}

const COLUMNS: { id: TaskStatus; label: string; color: string }[] = [
  { id: 'Pendiente', label: 'Pendiente', color: 'border-slate-300 dark:border-slate-700' },
  { id: 'En curso', label: 'En Curso', color: 'border-blue-400 dark:border-blue-600' },
  { id: 'Completada', label: 'Completada', color: 'border-emerald-400 dark:border-emerald-600' },
  { id: 'Bloqueada', label: 'Bloqueada / Riesgo', color: 'border-rose-400 dark:border-rose-600' },
];

export const KanbanView: React.FC<KanbanViewProps> = ({
  tasks,
  onUpdateStatus,
  onSelectTask,
}) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      {COLUMNS.map((col) => {
        const colTasks = tasks.filter((t) => t.estado === col.id);
        const colDays = colTasks.reduce((sum, t) => sum + t.duracion, 0);

        return (
          <div
            key={col.id}
            className={`bg-slate-50/80 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 rounded-lg p-3 flex flex-col min-h-[500px]`}
          >
            {/* Column Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800 mb-3">
              <div className="flex items-center gap-2">
                <span className="font-semibold text-xs text-slate-900 dark:text-slate-100 uppercase tracking-wider">
                  {col.label}
                </span>
                <span className="text-xs px-1.5 py-0.5 rounded bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-mono font-bold">
                  {colTasks.length}
                </span>
              </div>
              <span className="text-[11px] text-slate-400 font-mono tabular-nums">
                {colDays}d
              </span>
            </div>

            {/* Task Cards */}
            <div className="space-y-2.5 flex-1 overflow-y-auto">
              {colTasks.length === 0 ? (
                <div className="h-32 border border-dashed border-slate-200 dark:border-slate-800 rounded flex items-center justify-center text-xs text-slate-400">
                  Sin actividades
                </div>
              ) : (
                colTasks.map((task) => {
                  const isHighPriority = task.prioridad === 'Alta';

                  return (
                    <div
                      key={task.id}
                      className={`p-3 bg-white dark:bg-slate-800/90 border rounded-md shadow-xs transition-shadow hover:shadow-sm ${
                        task.esCritica
                          ? 'border-amber-300 dark:border-amber-700/80 ring-1 ring-amber-400/20'
                          : 'border-slate-200 dark:border-slate-700'
                      }`}
                    >
                      {/* Card Header */}
                      <div className="flex items-center justify-between text-[11px] mb-1.5">
                        <div className="flex items-center gap-1.5">
                          <span
                            className={`font-mono font-bold px-1.5 py-0.5 rounded text-[10px] ${
                              task.esCritica
                                ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-200'
                                : 'bg-slate-100 text-slate-700 dark:bg-slate-700 dark:text-slate-300'
                            }`}
                          >
                            #{task.id}
                          </span>
                          <span className="text-slate-500 dark:text-slate-400 font-medium">{task.fase}</span>
                        </div>

                        <span
                          className={`font-semibold text-[10px] ${
                            isHighPriority
                              ? 'text-red-600 dark:text-red-400'
                              : task.prioridad === 'Media'
                              ? 'text-emerald-600 dark:text-emerald-400'
                              : 'text-slate-500'
                          }`}
                        >
                          {task.prioridad}
                        </span>
                      </div>

                      {/* Title */}
                      <button
                        onClick={() => onSelectTask(task.id)}
                        className="text-xs font-semibold text-slate-900 dark:text-slate-100 hover:text-red-600 dark:hover:text-red-400 text-left line-clamp-2 transition-colors mb-2"
                      >
                        {task.actividad}
                      </button>

                      {/* Metadata */}
                      <div className="text-[11px] text-slate-500 dark:text-slate-400 space-y-1 mb-2.5">
                        <div className="truncate" title={task.responsable}>
                          👤 {task.responsable}
                        </div>
                        <div className="flex items-center justify-between font-mono text-[10px]">
                          <span>
                            Días {task.diaInicio}-{task.diaFin} ({task.duracion}d)
                          </span>
                          <span>{task.fechaInicio.slice(0, 5)} - {task.fechaFin.slice(0, 5)}</span>
                        </div>
                        {task.dependeDe !== '—' && (
                          <div className="text-[10px] text-slate-400 font-mono">
                            Depende de: #{task.dependeDe}
                          </div>
                        )}
                      </div>

                      {/* Status Transition Buttons */}
                      <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-700/60 text-xs">
                        <div className="flex items-center gap-1">
                          {col.id !== 'Pendiente' && (
                            <button
                              onClick={() => {
                                const prev: Record<TaskStatus, TaskStatus> = {
                                  'En curso': 'Pendiente',
                                  Completada: 'En curso',
                                  Bloqueada: 'En curso',
                                  Pendiente: 'Pendiente',
                                };
                                onUpdateStatus(task.id, prev[col.id]);
                              }}
                              title="Mover a estado anterior"
                              className="p-1 hover:bg-slate-100 dark:hover:bg-slate-700 rounded text-slate-500 hover:text-slate-900 dark:hover:text-slate-100 transition-colors"
                            >
                              <ArrowLeft className="w-3 h-3" />
                            </button>
                          )}
                          {col.id !== 'Completada' && (
                            <button
                              onClick={() => {
                                const next: Record<TaskStatus, TaskStatus> = {
                                  Pendiente: 'En curso',
                                  'En curso': 'Completada',
                                  Bloqueada: 'En curso',
                                  Completada: 'Completada',
                                };
                                onUpdateStatus(task.id, next[col.id]);
                              }}
                              title="Avanzar estado"
                              className="p-1 hover:bg-slate-100 dark:hover:bg-slate-700 rounded text-slate-500 hover:text-slate-900 dark:hover:text-slate-100 transition-colors"
                            >
                              <ArrowRight className="w-3 h-3" />
                            </button>
                          )}
                        </div>

                        {col.id !== 'Bloqueada' ? (
                          <button
                            onClick={() => onUpdateStatus(task.id, 'Bloqueada')}
                            className="text-[10px] text-rose-600 dark:text-rose-400 hover:underline"
                          >
                            Reportar Bloqueo
                          </button>
                        ) : (
                          <button
                            onClick={() => onUpdateStatus(task.id, 'En curso')}
                            className="text-[10px] text-blue-600 dark:text-blue-400 hover:underline"
                          >
                            Desbloquear
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
};
