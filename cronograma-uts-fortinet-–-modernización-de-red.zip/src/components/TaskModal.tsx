import React, { useState, useEffect } from 'react';
import { Task, Phase, Priority, TaskStatus } from '../types/project';
import { X, Check } from 'lucide-react';

interface TaskModalProps {
  isOpen: boolean;
  onClose: () => void;
  task?: Task | null;
  onSave: (taskData: Partial<Task>) => void;
  existingTasks: Task[];
}

export const TaskModal: React.FC<TaskModalProps> = ({
  isOpen,
  onClose,
  task,
  onSave,
  existingTasks,
}) => {
  const [fase, setFase] = useState<Phase>('Análisis');
  const [prioridad, setPrioridad] = useState<Priority>('Alta');
  const [actividad, setActividad] = useState('');
  const [responsable, setResponsable] = useState('');
  const [dependeDe, setDependeDe] = useState('—');
  const [duracion, setDuracion] = useState(3);
  const [estado, setEstado] = useState<TaskStatus>('Pendiente');
  const [notas, setNotas] = useState('');

  useEffect(() => {
    if (task) {
      setFase(task.fase);
      setPrioridad(task.prioridad);
      setActividad(task.actividad);
      setResponsable(task.responsable);
      setDependeDe(task.dependeDe);
      setDuracion(task.duracion);
      setEstado(task.estado);
      setNotas(task.notas || '');
    } else {
      setFase('Análisis');
      setPrioridad('Alta');
      setActividad('');
      setResponsable('Equipo del proyecto');
      setDependeDe('—');
      setDuracion(3);
      setEstado('Pendiente');
      setNotas('');
    }
  }, [task, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!actividad.trim()) return;

    onSave({
      ...(task ? { id: task.id } : {}),
      fase,
      prioridad,
      actividad,
      responsable,
      dependeDe: dependeDe.trim() || '—',
      duracion: Math.max(1, duracion),
      estado,
      notas,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg max-w-lg w-full shadow-xl overflow-hidden">
        {/* Header */}
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <h3 className="font-semibold text-sm text-slate-900 dark:text-slate-100">
            {task ? `Editar Actividad #${task.id}` : 'Añadir Nueva Actividad al Cronograma'}
          </h3>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-4 space-y-4 text-xs">
          <div>
            <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
              Actividad / Tarea *
            </label>
            <textarea
              required
              rows={2}
              value={actividad}
              onChange={(e) => setActividad(e.target.value)}
              placeholder="Descripción de la tarea a realizar en la modernización UTS..."
              className="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-1 focus:ring-red-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                Fase
              </label>
              <select
                value={fase}
                onChange={(e) => setFase(e.target.value as Phase)}
                className="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded text-slate-900 dark:text-slate-100 focus:outline-none"
              >
                <option value="Análisis">Análisis</option>
                <option value="Instalación">Instalación</option>
                <option value="Migración">Migración</option>
                <option value="Configuración">Configuración</option>
                <option value="Pruebas">Pruebas</option>
                <option value="Capacitación">Capacitación</option>
                <option value="Go-Live">Go-Live</option>
              </select>
            </div>

            <div>
              <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                Prioridad
              </label>
              <select
                value={prioridad}
                onChange={(e) => setPrioridad(e.target.value as Priority)}
                className="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded text-slate-900 dark:text-slate-100 focus:outline-none"
              >
                <option value="Alta">Alta (Rojo)</option>
                <option value="Media">Media (Verde)</option>
                <option value="Baja">Baja</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                Duración (Días Hábiles) *
              </label>
              <input
                type="number"
                min="1"
                max="60"
                required
                value={duracion}
                onChange={(e) => setDuracion(parseInt(e.target.value, 10) || 1)}
                className="w-full px-3 py-1.5 font-mono bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-1 focus:ring-red-500"
              />
            </div>

            <div>
              <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                Depende de (IDs separados por coma)
              </label>
              <input
                type="text"
                value={dependeDe}
                onChange={(e) => setDependeDe(e.target.value)}
                placeholder="Ej: 1, 2 o —"
                className="w-full px-3 py-1.5 font-mono bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded text-slate-900 dark:text-slate-100 focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                Responsable
              </label>
              <input
                type="text"
                value={responsable}
                onChange={(e) => setResponsable(e.target.value)}
                placeholder="Ej: Oficina de Recursos Informáticos"
                className="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded text-slate-900 dark:text-slate-100 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                Estado
              </label>
              <select
                value={estado}
                onChange={(e) => setEstado(e.target.value as TaskStatus)}
                className="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded text-slate-900 dark:text-slate-100 focus:outline-none"
              >
                <option value="Pendiente">Pendiente</option>
                <option value="En curso">En curso</option>
                <option value="Completada">Completada</option>
                <option value="Bloqueada">Bloqueada</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
              Notas Técnicas & Observaciones
            </label>
            <input
              type="text"
              value={notas}
              onChange={(e) => setNotas(e.target.value)}
              placeholder="Detalles técnicos o requisitos de entrega..."
              className="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded text-slate-900 dark:text-slate-100 focus:outline-none"
            />
          </div>

          {/* Footer Buttons */}
          <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 text-xs font-medium"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="inline-flex items-center gap-1.5 px-4 py-1.5 bg-red-600 hover:bg-red-700 text-white font-medium rounded text-xs transition-colors"
            >
              <Check className="w-3.5 h-3.5" />
              <span>Guardar Actividad</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
