import { Task, ProjectSettings } from '../types/project';

/**
 * Format date as DD/MM/YYYY
 */
export function formatDateDMY(date: Date): string {
  const day = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const year = date.getFullYear();
  return `${day}/${month}/${year}`;
}

/**
 * Parse DD/MM/YYYY or YYYY-MM-DD into a valid Date object at midnight local
 */
export function parseDateInput(str: string): Date {
  if (!str) return new Date();
  if (str.includes('/')) {
    const parts = str.split('/');
    if (parts.length === 3) {
      const day = parseInt(parts[0], 10);
      const month = parseInt(parts[1], 10) - 1;
      const year = parseInt(parts[2], 10);
      return new Date(year, month, day);
    }
  }
  if (str.includes('-')) {
    const parts = str.split('-');
    if (parts.length === 3) {
      const year = parseInt(parts[0], 10);
      const month = parseInt(parts[1], 10) - 1;
      const day = parseInt(parts[2], 10);
      return new Date(year, month, day);
    }
  }
  return new Date(str);
}

/**
 * Returns true if the day is Monday-Friday (1-5)
 */
export function isWorkingDay(date: Date): boolean {
  const day = date.getDay();
  return day !== 0 && day !== 6; // 0 = Sunday, 6 = Saturday
}

/**
 * Add N working days (1-indexed day offset)
 * workingDayIndex = 1 -> returns startDate (adjusted to next working day if weekend)
 * workingDayIndex = 2 -> next working day, etc.
 */
export function getDateForWorkingDay(startDate: Date, workingDayIndex: number): Date {
  const current = new Date(startDate.getTime());
  // Adjust starting date to next working day if on weekend
  while (!isWorkingDay(current)) {
    current.setDate(current.getDate() + 1);
  }

  let count = 1;
  while (count < workingDayIndex) {
    current.setDate(current.getDate() + 1);
    if (isWorkingDay(current)) {
      count++;
    }
  }
  return current;
}

/**
 * Parse dependency string e.g. "1, 2" or "3" or "—" into numeric task IDs
 */
export function parseDependencies(depStr: string): number[] {
  if (!depStr || depStr.trim() === '—' || depStr.trim() === '-' || depStr.trim() === '') {
    return [];
  }
  return depStr
    .split(',')
    .map((s) => parseInt(s.trim(), 10))
    .filter((n) => !isNaN(n) && n > 0);
}

/**
 * Recalculate the entire project schedule automatically:
 * - Solves diaInicio and diaFin based on dependencies and durations
 * - Computes calendar dates
 * - Determines weekly distribution (S1, S2, ...)
 * - Performs Forward & Backward pass to calculate Slack (Holgura) and Critical Path
 */
export function recalculateSchedule(
  tasks: Task[],
  projectStartDateStr: string,
  diasPorSemana: number = 5
): { recalculatedTasks: Task[]; settings: ProjectSettings } {
  const startDate = parseDateInput(projectStartDateStr);

  // Clone tasks
  const updatedTasks: Task[] = tasks.map((t) => ({ ...t }));

  // Map by id for fast lookup
  const taskMap = new Map<number, Task>();
  updatedTasks.forEach((t) => taskMap.set(t.id, t));

  // Determine calculation order with topological or relaxation loop
  // Max 50 iterations to avoid infinite loops with circular dependencies
  let changed = true;
  let iterations = 0;

  // Initialize
  updatedTasks.forEach((task) => {
    task.diaInicio = 1;
    task.duracion = Math.max(1, task.duracion || 1);
    task.diaFin = task.diaInicio + task.duracion - 1;
  });

  while (changed && iterations < 50) {
    changed = false;
    iterations++;

    for (const task of updatedTasks) {
      const depIds = parseDependencies(task.dependeDe);
      let calculatedStart = 1;

      if (depIds.length > 0) {
        let maxDepEnd = 0;
        for (const depId of depIds) {
          const depTask = taskMap.get(depId);
          if (depTask) {
            maxDepEnd = Math.max(maxDepEnd, depTask.diaFin);
          }
        }
        calculatedStart = maxDepEnd + 1;
      }

      if (task.diaInicio !== calculatedStart) {
        task.diaInicio = calculatedStart;
        task.diaFin = task.diaInicio + task.duracion - 1;
        changed = true;
      }
    }
  }

  // Calculate project end day and total weeks
  let maxProjectDay = 1;
  updatedTasks.forEach((t) => {
    maxProjectDay = Math.max(maxProjectDay, t.diaFin);
  });

  const totalSemanas = Math.max(8, Math.ceil(maxProjectDay / diasPorSemana));
  const projectEndDate = getDateForWorkingDay(startDate, maxProjectDay);

  // Backward pass to compute Late Start (LS), Late Finish (LF) and Slack (Holgura)
  // Build successor map
  const successorMap = new Map<number, number[]>();
  updatedTasks.forEach((t) => successorMap.set(t.id, []));

  updatedTasks.forEach((t) => {
    const deps = parseDependencies(t.dependeDe);
    deps.forEach((depId) => {
      if (successorMap.has(depId)) {
        successorMap.get(depId)!.push(t.id);
      }
    });
  });

  // Calculate late finish and late start
  const lateFinishMap = new Map<number, number>();
  const lateStartMap = new Map<number, number>();

  // Sort tasks descending by diaFin for backward pass
  const sortedDesc = [...updatedTasks].sort((a, b) => b.diaFin - a.diaFin);

  for (const task of sortedDesc) {
    const successors = successorMap.get(task.id) || [];
    let lf = maxProjectDay;

    if (successors.length > 0) {
      let minSuccLS = Infinity;
      for (const succId of successors) {
        const succLS = lateStartMap.get(succId) ?? taskMap.get(succId)!.diaInicio;
        minSuccLS = Math.min(minSuccLS, succLS);
      }
      lf = minSuccLS - 1;
    }

    const ls = lf - task.duracion + 1;
    lateFinishMap.set(task.id, lf);
    lateStartMap.set(task.id, ls);

    const holgura = Math.max(0, ls - task.diaInicio);
    task.holgura = holgura;
    task.esCritica = holgura === 0;

    // Calculate dates
    const startDateObj = getDateForWorkingDay(startDate, task.diaInicio);
    const endDateObj = getDateForWorkingDay(startDate, task.diaFin);
    task.fechaInicio = formatDateDMY(startDateObj);
    task.fechaFin = formatDateDMY(endDateObj);

    // Compute active weeks
    task.semanas = [];
    for (let w = 1; w <= totalSemanas; w++) {
      const weekStartDay = (w - 1) * diasPorSemana + 1;
      const weekEndDay = w * diasPorSemana;
      const isActive = task.diaInicio <= weekEndDay && task.diaFin >= weekStartDay;
      task.semanas.push(isActive);
    }
  }

  const settings: ProjectSettings = {
    fechaInicio: formatDateDMY(startDate),
    diasPorSemana,
    totalSemanas,
    totalDiasHabiles: maxProjectDay,
    fechaFin: formatDateDMY(projectEndDate),
  };

  return { recalculatedTasks: updatedTasks, settings };
}

/**
 * Generate dates header for weeks
 */
export function getWeekDateRanges(startDate: Date, totalWeeks: number, diasPorSemana: number = 5): {
  semana: number;
  label: string;
  rango: string;
  dias: string;
}[] {
  const result = [];
  for (let w = 1; w <= totalWeeks; w++) {
    const startDayIdx = (w - 1) * diasPorSemana + 1;
    const endDayIdx = w * diasPorSemana;
    const sDate = getDateForWorkingDay(startDate, startDayIdx);
    const eDate = getDateForWorkingDay(startDate, endDayIdx);

    result.push({
      semana: w,
      label: `S${w}`,
      rango: `${formatDateDMY(sDate).slice(0, 5)} - ${formatDateDMY(eDate).slice(0, 5)}`,
      dias: `D${startDayIdx}-D${endDayIdx}`,
    });
  }
  return result;
}
