import { Task, ProjectSettings } from '../types/project';

/**
 * Export current project tasks to CSV
 */
export function exportTasksToCSV(tasks: Task[], settings: ProjectSettings): void {
  const headers = [
    '#',
    'Fase',
    'Prioridad',
    'Actividad / Tarea',
    'Responsable',
    'Depende de',
    'Duración (días)',
    'Día inicio',
    'Día fin',
    'Fecha inicio',
    'Fecha fin',
    'Estado',
    'Holgura (días)',
    'Es Crítica',
    ...Array.from({ length: settings.totalSemanas }, (_, i) => `S${i + 1}`),
  ];

  const escapeCSV = (val: any) => {
    if (val === undefined || val === null) return '';
    const str = String(val);
    if (str.includes(',') || str.includes('"') || str.includes('\n')) {
      return `"${str.replace(/"/g, '""')}"`;
    }
    return str;
  };

  const rows = tasks.map((task) => [
    task.id,
    task.fase,
    task.prioridad,
    task.actividad,
    task.responsable,
    task.dependeDe,
    task.duracion,
    task.diaInicio,
    task.diaFin,
    task.fechaInicio,
    task.fechaFin,
    task.estado,
    task.holgura ?? 0,
    task.esCritica ? 'SÍ' : 'NO',
    ...task.semanas.map((active) => (active ? 'X' : '')),
  ]);

  const csvContent = [
    `# Proyecto: Modernización de infraestructura de red UTS (Fortinet Security Fabric)`,
    `# Fecha de inicio: ${settings.fechaInicio} | Días hábiles/semana: ${settings.diasPorSemana} | Semanas totales: ${settings.totalSemanas}`,
    headers.map(escapeCSV).join(','),
    ...rows.map((r) => r.map(escapeCSV).join(',')),
  ].join('\n');

  // Trigger download with UTF-8 BOM so Excel opens it with accents correctly
  const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `Cronograma_UTS_Fortinet_${new Date().toISOString().slice(0, 10)}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
