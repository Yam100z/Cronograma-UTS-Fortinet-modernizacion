export type Priority = 'Alta' | 'Media' | 'Baja';

export type TaskStatus = 'Pendiente' | 'En curso' | 'Completada' | 'Bloqueada';

export type Phase =
  | 'Análisis'
  | 'Instalación'
  | 'Migración'
  | 'Configuración'
  | 'Pruebas'
  | 'Capacitación'
  | 'Go-Live';

export interface Task {
  id: number;
  fase: Phase;
  prioridad: Priority;
  actividad: string;
  responsable: string;
  dependeDe: string; // e.g. "—", "1, 2", "3", "4, 5"
  duracion: number; // working days
  diaInicio: number;
  diaFin: number;
  fechaInicio: string; // DD/MM/YYYY
  fechaFin: string; // DD/MM/YYYY
  estado: TaskStatus;
  semanas: boolean[]; // S1 to S8 (or more if extended)
  esCritica?: boolean;
  holgura?: number; // Slack days
  progreso?: number; // 0 to 100%
  notas?: string;
}

export interface ProjectSettings {
  fechaInicio: string; // YYYY-MM-DD or DD/MM/YYYY
  diasPorSemana: number;
  totalSemanas: number;
  totalDiasHabiles: number;
  fechaFin: string;
}

export interface FortinetComponent {
  nombre: string;
  modelo: string;
  rol: string;
  capacidad: string;
  redundancia: string;
  estado: 'Validado' | 'En evaluación' | 'Por adquirir';
}
